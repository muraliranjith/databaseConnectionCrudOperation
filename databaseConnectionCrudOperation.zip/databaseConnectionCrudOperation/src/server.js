const express = require('express');
const cors = require('cors');
const router = require('./routes/product.route');

const app = express();

var corOptions = {
    origin: 'http://localhost:8081'
}

//middlewares

app.use(cors(corOptions))
app.use(express.json())
app.use(express.urlencoded({extended:true}))

// routers 

app.use('/api/products',router)

//testing

app.get('/', (req,res)=>{
    res.json({message: 'Hello From API'})
})
//port
const PORT = 3000

// server

app.listen(PORT,()=>{
    console.log(`server is running port ${PORT}`);
})