const db = require('../models/index')

//create main model

const Product = db.products
// main work

//1. create product

const addProduct = async (req, res) => {
    let payload = {
        title: req.body.title,
        price: req.body.price,
        description: req.body.description,
        published: req.body.published ? req.body.published : false
    }
    const product = await Product.create(payload)
    res.status(200).send(product);
    console.log(product);
}

// 2. get all products

const getAllProducts = async (req, res) => {
    let products = await Product.findAll({})
    res.status(200).send(products)
}

//3. get single product

const getOneProduct = async (req, res) => {
    let id = req.params.id;
    let products = await Product.findByPk(id)
    res.status(200).send(products)
}

// 4. update Product

const updateProduct = async (req, res) => {
    let id = req.params.id;
    let products = await Product.update(req.body, { where: { id: id } })
    res.status(200).send(products)
}

//5. delete product by Id


const deleteProduct = async (req, res) => {
    let id = req.params.id;
    await Product.destroy({ where: { id: id } })
    res.status(200).send('products is deleted')

}

//6. get Published Product

const getPublishedProduct = async (req, res) => {
    let products = await Product.findAll({ where: { published: false } })
    res.status(200).send(products)
}
module.exports = {
    addProduct,
    getAllProducts,
    getOneProduct,
    updateProduct,
    deleteProduct,
    getPublishedProduct
}